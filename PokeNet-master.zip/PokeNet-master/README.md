# PokeNet

1. Must have Jupyter Notebook
2. Must get image dataset from here: https://drive.google.com/file/d/1elLTiHX-KZw9dnkDP-9skKXNpUFPTS8T/view?usp=sharing
3. Must install CV, and TensorFlow manually to Anaconda
4. Train
